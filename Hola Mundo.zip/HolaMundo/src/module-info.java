/**
 * 
 */
/**
 * @author junca
 *
 */
module HolaMundo {
}